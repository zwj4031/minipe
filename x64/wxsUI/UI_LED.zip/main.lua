
show_text = "���һ�ӭ��λ�쵼ݰ��ָ����"
lshift_index = 0

TIMER_ID_FLUSH_TEXT = 1001

function lshift_text()
   local new_text = show_text:sub(lshift_index + 1)
   lshift_index = lshift_index + 2  -- ȫ���֣�һ���ƶ�2���ֽ�
   if lshift_index > show_text:len() then lshift_index = 0 end
   return "<b>" .. new_text .. "</b>"
end

function onload()
    elem_label_info = sui:find('label_info')
    suilib.call('SetTimer', TIMER_ID_FLUSH_TEXT, 300)
end

function ontimer(id)
    elem_label_info.text = lshift_text()
end
