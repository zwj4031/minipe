local function set_res(name, id, file)
  file = file or 'systemcpl.dll'
  sui:find(name).text = str.format('#{@%s,%s}', file, id)
end

local function set_text(name, text)
  sui:find(name).text = text
end

TICK_TIMER_ID = 1000
timetick_format = '%02d:%02d:%02d'
runtime_text = nil

local function update_timetick()
  -- body
  local tick = suilib.call('GetTickCount')
  tick = math.floor(tick / 1000) -- sec
  local h = math.floor(tick / 3600)
  local m = math.floor((tick - h * 3600) / 60)
  local s = tick % 60
  local t = string.format(timetick_format, h, m, s)
  runtime_text.text = t
end

function onload()
  --p(os_ver_info()['ProductName'])
  --p(win_copyright())

  local vernum = app:info('winver')

  sui:find('title').text = '#{@systemcpl.dll,1}'
  sui:find('cphome_btn').text = '#{@shell32.dll,31057}'
  sui:find('devmgmt_btn').text = '#{@systemcpl.dll,100}'
  sui:find('rmt_btn').text = '#{@systemcpl.dll,101}'
  sui:find('protect_btn').text = '#{@systemcpl.dll,102}'
  sui:find('adv_btn').text = '#{@systemcpl.dll,103}'
  sui:find('act_btn').text = '#{@systemcpl.dll,105}'
  sui:find('more_label').text = '#{@shell32.dll,31091}'
  sui:find('update_btn').text = '#{@systemcpl.dll,104}'

  if vernum == '6.1' then  -- Windows 7
    local perf_btn = sui:find('perf_btn')
    perf_btn.text = '#{@systemcpl.dll,106}'
    perf_btn.visible = 1
  end

  set_res('basic_label', 1537)
  set_res('edition_group',1538)

  local ver_info = os_ver_info()

  if ver_info then -- need Administrator's right privilege to read the HKLM items
    local ver_text = str.format('%s\r\n#{@Branding\\Basebrd\\basebrd.dll,14}',
      ver_info['ProductName'])

    if (ver_info['CSDVersion']) then -- Windows 10 hasn't 'Service Pack x'
      ver_text = ver_text .. '\r\n' .. ver_info['CSDVersion']
    else
      local rsN = reg_read([[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion]]
        , 'BuildBranch')
      if rsN then ver_text = ver_text .. '\r\n' .. rsN end
    end
    set_text('edition_edit', ver_text)
  end

  local win_logo = 'windows'
  if vernum == '6.1' or vernum == '10.0' then win_logo = 'win_' .. vernum end

  local installation_type = reg_read([[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion]]
    , 'InstallationType')
  if installation_type and installation_type == 'Server' then
    win_logo = 'win_server'
  end
  sui:find('brand_img').bkimage = "file='" .. win_logo .. ".png'"

  set_res('system_group', 1542)
  set_res('mfgr_label', 1572)
  set_res('model_label', 1574)
  set_res('cpu_label', 1562)
  set_res('mem_label', 1564)
  set_res('arch_label',1571)

  local need_si_height = 0
  local mfgr_info = reg_read([[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation]]
        , 'Manufacturer')

  if mfgr_info then
    need_si_height = 20
    set_text('mfgr_text', mfgr_info)
  else
     sui:find('mfgr_label').visible = 0
     sui:find('mfgr_text').visible = 0
  end

  local model_info = reg_read([[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation]]
        , 'Model')

  if model_info then
    need_si_height = need_si_height + 20
    set_text('model_text', model_info)
  else
     sui:find('model_label').visible = 0
     sui:find('model_text').visible = 0
  end

  if need_si_height > 0 then
    sui:find('system_info').height = 120 + need_si_height
  end

  local cpu_t = cpu_info()

  if cpu_t then -- need Administrator's right privilege to read the HKLM items
    local cpu_f = cpu_t['~MHz']
    cpu_f = cpu_f / 1000
    cpu_str = str.format("%s %.2fGHz", cpu_t['ProcessorNameString'], cpu_f)
    set_text('cpu_text', cpu_str)
  end

  -- local mem_format = mui_str('systemcpl.dll', 45)
  local mem_format = suilib.call('resstr', '#{@systemcpl.dll,45}')

  local mem_t = mem_info()
  local total_phys = mem_t[1]
  local avail_phys = mem_t[2]
  total_phys = total_phys / 1024 / 1024
  avail_phys = avail_phys / 1024 / 1024 / 1024
  if total_phys == 0 then -- GetPhysicallyInstalledSystemMemory() failed in WinPE
    total_phys = avail_phys
  end
  total_phys = str.format("%.2f GB", total_phys)
  avail_phys = str.format("%.2f GB", avail_phys)
  local now_avail = mem_t[3] / 1024 /1024 /1024
  now_avail = str.format("#{@shell32.dll,9307} %.2f GB", now_avail)
  local mem_s = str.format(mem_format, total_phys, avail_phys)
  set_text('mem_text', mem_s .. '    ' .. now_avail)

  local arch_id = 0
  if ARCH == 'x86' then
    arch_id = 56 -- Windows 10
    if vernum == "6.1" then arch_id = 23 end -- Windows 7
  else
    arch_id = 60 -- Windows 10
    if vernum == "6.1" then arch_id = 24 end -- Windows 7
  end
  set_res('arch_text', arch_id)

  set_res('host_group', 1545)
  set_res('host_label', 1547)
  set_res('fqdn_label', 1549)
  set_res('desc_label', 1551)
  set_res('workgroup_label', 1553)
  set_res('host_settings_btn', 1546)

  local computername = reg_read([[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName]]
        , 'ComputerName')

  set_text('host_text', computername)
  set_text('fqdn_text', computername)
  set_text('desc_text', '')
  local wg = os.getenv('USERDNSDOMAIN') or 'WorkGroup'
  set_text('workgroup_text', wg)

  set_text('status_group', 'Windows #{@shell32.dll,8981}')

  local ticklabel = suilib.call('resstr', '#{@shell32.dll,25379}')
  _, _, ticklabel = string.find(ticklabel, '(.-);')
  set_text('runtime_label', ticklabel)

  timetick_format = suilib.call('resstr', '#{@shell32.dll,28876} #{@shell32.dll,28879} #{@shell32.dll,28882}')
  timetick_format = string.gsub(timetick_format, '%%1!d!', '%%02d')
  runtime_text = sui:find('runtime_text')
  update_timetick()
  suilib.call('SetTimer', TICK_TIMER_ID, 1000)

  if app:info('locale') == 'zh-CN' then
    sui:find('edition_group').width = 85
    sui:find('system_group').width = 30
    sui:find('host_group').width = 148
    sui:find('status_group').width = 100
  end

end

function ontimer(id)
  if id == TICK_TIMER_ID then
    update_timetick()
  end
end

function onclick(ctrl)
  if ctrl == 'cphome_btn' then
    suilib.call('run', 'control')
  elseif ctrl == 'devmgmt_btn' then
    -- lua built-in function, but with cmd.exe's black window flushing
    --os.execute('start devmgmt.msc')
    suilib.call('run', 'devmgmt.msc')
  elseif ctrl == 'rmt_btn' then
    suilib.call('run', 'systempropertiesremote.exe')
  elseif ctrl == 'protect_btn' then
    suilib.call('run', 'systempropertiesprotection.exe')
  elseif ctrl == 'adv_btn' then
    suilib.call('run', 'systempropertiesadvanced.exe')
  elseif ctrl == 'host_settings_btn' then
    suilib.call('run', 'systempropertiescomputername.exe')
  end
end
